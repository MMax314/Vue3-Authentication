export { default as HomeView } from './HomeView.vue';
export { default as LoginView } from './LoginView.vue';
